package com.microservice.profileservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfileserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
